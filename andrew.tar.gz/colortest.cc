#include <iostream>
#include <cstdlib>
#include <cctype>
using namespace std;

const string RESET("\033[0m");
const string RED("\033[0;31m");
const string GREEN("\033[1;32m");
const string WHITE("\033[1;37m");
const string GRAY("\033[0;37m");
const string DARKER("\033[2;37m");
const string BLACK("\033[0;30m");
const string DARKER2("\033[1;1m");
const string DARKER3("\033[0;2m");
const string DARKER4("\033[0;3m");
const string DARKER5("\033[0;4m");
const string DARKER6("\033[0;5m");
const string DARKER7("\033[0;6m");
const string DARKER8("\033[0;7m");
const string DARKER9("\033[0;8m");
const string DARKER10("\033[0;9m");
const string DARKER11("\033[0;10m");
const string DARKER12("\033[0;12m");
int main() {
	cerr << WHITE << endl;
	cerr << "White\n";
	cerr << GRAY << endl;
	cerr << "Gray\n";
	cerr << DARKER << endl;
	cerr << "Gray\n";
	cerr << DARKER2 << endl;
	cerr << "Gray\n";
	cerr << DARKER3 << endl;
	cerr << "Gray\n";
	cerr << DARKER4 << endl;
	cerr << "Gray\n";
	cerr << DARKER5 << endl;
	cerr << "Gray\n";
	cerr << DARKER6 << endl;
	cerr << "Gray\n";
	cerr << DARKER7 << endl;
	cerr << "Gray\n";
	cerr << DARKER8 << endl;
	cerr << "Gray\n";
	cerr << DARKER9 << endl;
	cerr << "Gray\n";
	cerr << DARKER10 << endl;
	cerr << "Gray\n";
	cerr << DARKER11 << endl;
	cerr << "Gray\n";
	cerr << DARKER12 << endl;
	cerr << "Gray\n";
	cerr << RESET << endl;
}	
